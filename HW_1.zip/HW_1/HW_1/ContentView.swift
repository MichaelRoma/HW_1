//
//  ContentView.swift
//  HW_1
//
//  Created by Mykhailo Romanovskyi on 22.07.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var buttonTitle = "Press"
    @State private var opacityRed = 0.5
    @State private var opacityYellow = 0.5
    @State private var opacityGreen = 0.5
    
    var body: some View {
        VStack{
            ColorCircle(color: .red, opacity: opacityRed)
            ColorCircle(color: .yellow, opacity: opacityYellow)
            ColorCircle(color: .green, opacity: opacityGreen)
            Spacer()
            Button(action: { self.buttonPressAction() }) {
                Text(buttonTitle)
                    .font(.largeTitle)
            }
        }.padding()
    }
    
    private func buttonPressAction() {
        if buttonTitle == "Press" {
            self.buttonTitle = "Next"
            opacityRed = 1
            return
        }
        
        if opacityRed == 1 {
            opacityRed = 0.5
            opacityYellow = 1
        } else if opacityYellow == 1 {
            opacityYellow = 0.5
            opacityGreen = 1
        } else {
            opacityGreen = 0.5
            opacityRed = 1
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
