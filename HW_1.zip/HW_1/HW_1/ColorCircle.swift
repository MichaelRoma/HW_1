//
//  Circle.swift
//  HW_1
//
//  Created by Mykhailo Romanovskyi on 22.07.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import SwiftUI

struct ColorCircle: View {
    let color: UIColor
    let opacity: Double
    var body: some View {
        Color(color).opacity(opacity)
            .frame(width: 80, height: 80)
            .clipShape(Circle())
            .overlay(Circle().stroke(Color.white, lineWidth: 2))
            .shadow(radius: 10)
    }
}

struct Circle_Previews: PreviewProvider {
    static var previews: some View {
        ColorCircle(color: .red, opacity: 0.6)
    }
}
